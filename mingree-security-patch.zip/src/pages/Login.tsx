import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth-context";

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    // Purge stale local storage mock users to prevent client-side login bypasses
    try {
      localStorage.removeItem("mingree_registered_users");
    } catch {}
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage(null);
    const cleanEmail = email.trim().toLowerCase();

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: cleanEmail, password }),
        credentials: "include",
      });

      let data: any = {};
      try {
        const text = await response.text();
        const trimmed = text ? text.trim() : "";
        if (trimmed && (trimmed.startsWith("{") || trimmed.startsWith("["))) {
          data = JSON.parse(trimmed);
        }
      } catch {
        data = {};
      }

      if (!response.ok) {
        throw new Error(data.error || "Invalid email or password");
      }

      queryClient.setQueryData(["currentUser"], data);

      setIsSuccess(true);
      toast.success(`Welcome back, ${data.name || data.email}!`);

      login(data);
      queryClient.invalidateQueries({ queryKey: ["currentUser"] });

      setTimeout(() => {
        if (data.role === "admin") {
          window.location.href = "/admin";
        } else if (data.role === "sponsor") {
          window.location.href = "/sponsor";
        } else {
          window.location.href = "/dashboard";
        }
      }, 300);
    } catch (error) {
      const rawMsg = error instanceof Error ? error.message : "Invalid email or password";
      const safeMsg =
        rawMsg.includes("expected pattern") || rawMsg.includes("SyntaxError") || rawMsg.includes("JSON")
          ? "Invalid email or password"
          : rawMsg;
      setErrorMessage(safeMsg);
      toast.error(safeMsg);
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-background flex flex-col justify-between p-4 sm:p-6">
      {/* Top bar */}
      <div className="flex items-center justify-between max-w-md w-full mx-auto pt-2">
        <Link href="/">
          <div className="flex items-center gap-2.5 cursor-pointer">
            <img src="/assets/aistudio/Glossy_Mingree_Ribbon_App_Icon_847ced8d.png" alt="Mingree Logo" className="w-8 h-8 rounded-xl object-cover shadow-sm" />
            <span className="text-lg font-bold text-foreground tracking-tight">Mingree</span>
          </div>
        </Link>
        <Link href="/about">
          <Button variant="ghost" size="sm" className="text-xs text-muted-foreground hover:text-foreground h-8">
            How It Works
          </Button>
        </Link>
      </div>

      {/* Main Card */}
      <div className="w-full max-w-md mx-auto my-auto">
        <Card className="border-border bg-card shadow-sm rounded-xl">
          <CardHeader className="text-center pt-8 pb-4">
            <CardTitle className="text-2xl font-bold tracking-tight text-foreground">Welcome Back</CardTitle>
            <CardDescription className="text-xs sm:text-sm text-muted-foreground mt-1">
              Log in to access your campaigns and earnings
            </CardDescription>
          </CardHeader>

          <CardContent className="px-6 pb-8 space-y-4">
            {errorMessage && (
              <div className="rounded-lg bg-destructive/10 border border-destructive/30 p-3 text-xs text-destructive font-medium flex items-center justify-between">
                <span>{errorMessage}</span>
                <button type="button" onClick={() => setErrorMessage(null)} className="text-destructive/70 hover:text-destructive text-sm font-bold ml-2">×</button>
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs font-semibold text-foreground">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-10 text-xs"
                  required
                  data-testid="input-email"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-xs font-semibold text-foreground">Password</Label>
                  <button
                    type="button"
                    onClick={() => setLocation("/forgot-password")}
                    className="text-xs text-muted-foreground hover:text-foreground font-medium cursor-pointer"
                    data-testid="link-forgot-password"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-10 text-xs pr-14"
                    required
                    data-testid="input-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground cursor-pointer"
                    data-testid="button-toggle-password"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>
              </div>

              <div className="rounded-lg border border-border/80 bg-muted/40 px-3 py-2 text-[11px] text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">Age Requirement (13+):</span> You must be at least 13 years old to use Mingree.
              </div>

              <Button
                type="submit"
                className="w-full h-10 text-xs font-semibold cursor-pointer"
                disabled={isLoading || isSuccess}
                data-testid="button-login"
              >
                {isSuccess ? "Redirecting..." : isLoading ? "Signing in..." : "Log In"}
              </Button>
            </form>

            <div className="pt-4 text-center border-t border-border">
              <p className="text-muted-foreground text-xs">
                Don't have an account?{" "}
                <button
                  onClick={() => setLocation("/signup")}
                  className="text-foreground font-semibold hover:underline"
                  data-testid="link-signup"
                >
                  Create an account
                </button>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="max-w-md w-full mx-auto text-center py-2">
        <p className="text-[11px] text-muted-foreground">
          By logging in, you confirm you are 13+ years old and agree to Mingree's{" "}
          <Link href="/terms"><span className="underline cursor-pointer">Terms</span></Link> and{" "}
          <Link href="/privacy"><span className="underline cursor-pointer">Privacy Policy</span></Link>.
        </p>
      </div>
    </div>
  );
}
