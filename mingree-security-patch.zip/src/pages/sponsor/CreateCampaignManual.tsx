import { useMemo } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { SponsorSidebar } from "@/components/SponsorSidebar";
import { ManualCampaignPage } from "@/features/manual-campaign/ManualCampaignPage";
import { createHttpApi } from "@/features/manual-campaign/httpApi";

// "Choose creators" campaign page. Route: /sponsor/create-campaign/manual
export default function CreateCampaignManual() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const api = useMemo(() => createHttpApi(), []);
  return (
    <div className="flex min-h-screen w-full max-w-full overflow-x-hidden bg-background">
      <SponsorSidebar />
      <main className="flex-1 w-full max-w-full min-w-0 overflow-x-hidden overflow-y-auto pt-14 md:pt-0 pb-20 md:pb-6">
        <ManualCampaignPage
          api={api}
          onBack={() => navigate("/sponsor/create-campaign")}
          onAddMoney={() => navigate("/sponsor/wallet")}
          onCreated={(campaignId) => {
            queryClient.invalidateQueries({ queryKey: ["brandCampaignCards"] });
            queryClient.invalidateQueries({ queryKey: ["campaignWorkspace"] });
            queryClient.invalidateQueries({ queryKey: ["sponsorWallet"] });
            queryClient.invalidateQueries({ queryKey: ["currentSponsor"] });
            toast.success("Campaign launched! Opening campaign workspace folder...");
            if (campaignId) {
              navigate(`/sponsor/campaigns/${campaignId}/workspace`);
            } else {
              navigate("/sponsor/campaigns");
            }
          }}
        />
      </main>
    </div>
  );
}

