import type { ManualCampaignApi, CreatorSearchParams, CreatorCard, CreatorSearchResult, City } from "./types";

const FALLBACK_CITIES: City[] = [
  { id: 1, name: "Mumbai", state: "Maharashtra" },
  { id: 2, name: "Delhi", state: "Delhi" },
  { id: 3, name: "Bangalore", state: "Karnataka" },
  { id: 4, name: "Hyderabad", state: "Telangana" },
  { id: 5, name: "Chennai", state: "Tamil Nadu" },
  { id: 6, name: "Kolkata", state: "West Bengal" },
  { id: 7, name: "Pune", state: "Maharashtra" },
  { id: 8, name: "Ahmedabad", state: "Gujarat" },
  { id: 9, name: "Jaipur", state: "Rajasthan" },
  { id: 10, name: "Lucknow", state: "Uttar Pradesh" },
];

function buildFallbackCreators(p: CreatorSearchParams): CreatorSearchResult {
  const reqTier = (p.tierId || "micro").toLowerCase();
  const deliverable = p.deliverable || "reel";
  let multiplier = 1.0;
  if (deliverable === "story") multiplier = 0.5;
  else if (deliverable === "collab_post") multiplier = 1.4;
  else if (deliverable === "bio_link_story") multiplier = 0.6;

  const tierBasePrices: Record<string, number> = {
    nano: 1200,
    micro: 2800,
    mid: 6500,
    upper_mid: 15000,
    macro: 32000,
    large: 65000,
    mega: 125000,
    elite: 250000,
  };
  const basePrice = tierBasePrices[reqTier] || 2800;
  const currentPrice = Math.round(basePrice * multiplier);

  const items: CreatorCard[] = [];

  let filteredItems = items;
  if (p.q) {
    const qLower = p.q.toLowerCase().trim();
    filteredItems = filteredItems.filter(
      (c) => c.username.toLowerCase().includes(qLower) || c.displayName.toLowerCase().includes(qLower)
    );
  }

  // Sort by reach & views by default
  filteredItems.sort((a, b) => {
    if (a.isRealRegisteredCreator !== b.isRealRegisteredCreator) return a.isRealRegisteredCreator ? -1 : 1;
    if (p.sort === "price_asc") return a.price - b.price;
    if (p.sort === "price_desc") return b.price - a.price;
    if (p.sort === "followers_desc") return b.followers - a.followers;
    if (p.sort === "engagement_desc") return (b.engagementRate || 0) - (a.engagementRate || 0);
    // Default / reach_desc / views_desc: Highest reach & views on top
    const scoreA = ((a.reach || 0) * 2) + ((a.medianViews || 0) * 3);
    const scoreB = ((b.reach || 0) * 2) + ((b.medianViews || 0) * 3);
    return scoreB - scoreA;
  });

  return {
    items: filteredItems,
    total: filteredItems.length,
    nextCursor: null,
  };
}

// Real API client. Endpoints are defined in the Mingree v6 pack (Step 7 and Step 8).
async function j<T>(res: Response): Promise<T> {
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err: any = new Error(body?.error || `Request failed (${res.status})`);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body as T;
}

function getAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {};
  try {
    const sessionStr = localStorage.getItem("mingree_auth_session_v1");
    if (sessionStr) {
      const parsed = JSON.parse(sessionStr);
      if (parsed?.id) {
        headers["X-User-Id"] = String(parsed.id);
      }
    }
  } catch {}
  return headers;
}

export function createHttpApi(base = ""): ManualCampaignApi {
  const opts = { credentials: "include" as const };
  return {
    listCities: async () => {
      try {
        const res = await fetch(`${base}/api/cities`, { ...opts, headers: getAuthHeaders() });
        if (res.ok) return await res.json();
      } catch {}
      return FALLBACK_CITIES;
    },
    searchCreators: async (p: CreatorSearchParams): Promise<CreatorSearchResult> => {
      try {
        const qs = new URLSearchParams();
        if (p.city && p.city !== "all") qs.set("city", p.city);
        if (p.cityIds?.length) qs.set("cities", p.cityIds.join(","));
        if (p.tierId && p.tierId !== "all") qs.set("tier", p.tierId);
        if (p.deliverable) qs.set("deliverable", p.deliverable);
        if (p.q) qs.set("q", p.q);
        if (p.minEngagement) qs.set("minEngagement", String(p.minEngagement));
        if (p.genres?.length) qs.set("genres", p.genres.join(","));
        if (p.sort) qs.set("sort", p.sort);
        if (p.cursor) qs.set("cursor", p.cursor);

        const res = await fetch(`${base}/api/campaigns/creator-panel?${qs}`, {
          ...opts,
          headers: getAuthHeaders(),
        });
        if (res.ok) {
          const data = await res.json();
          if (data && Array.isArray(data.items)) {
            return data;
          }
        }
      } catch (err) {
        console.warn("Creator panel fetch encountered an error, falling back cleanly:", err);
      }
      return buildFallbackCreators(p);
    },
    previewBill: (input) =>
      fetch(`${base}/api/campaigns/choose-creators/bill`, {
        ...opts,
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify(input),
      }).then((r) => j(r)),
    submit: async (p) => {
      const res = await fetch(`${base}/api/campaigns/choose-creators`, {
        ...opts,
        method: "POST",
        headers: { "Content-Type": "application/json", ...getAuthHeaders() },
        body: JSON.stringify(p),
      });
      const body: any = await res.json().catch(() => ({}));
      if (res.ok) return { ok: true, campaignId: body.campaignId };
      if (res.status === 409) return { ok: false, reason: "bill_changed", bill: body.bill };
      if (res.status === 402) return { ok: false, reason: "insufficient_funds", bill: body.bill };
      return { ok: false, reason: "error", message: body?.error || "Something went wrong" };
    },
  };
}
