import { useCallback, useEffect, useMemo, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { compact, inr } from "./tiers";
import type { Bill, CampaignDetails, CreatorCard, CreatorSearchParams, DeliverableType, ManualCampaignApi, SubmitResult } from "./types";
import { CreatorAvatar } from "@/components/CreatorAvatar";
import { ArrowLeft } from "lucide-react";
import { CITIES_BY_COUNTRY } from "@shared/cities";
import { INDIAN_GENRES } from "@shared/genres";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Dummy icon fallbacks for removed icons
const __DummyIcon = () => null;
const Wallet = __DummyIcon;
const Instagram = __DummyIcon;
const Upload = __DummyIcon;
const File = __DummyIcon;
const Check = __DummyIcon;

const DELIVERABLES: { id: DeliverableType; label: string; shortLabel: string }[] = [
  { id: "reel", label: "Instagram Reel", shortLabel: "Reel" },
  { id: "story", label: "Instagram Story", shortLabel: "Story" },
  { id: "collab_post", label: "Collab Package", shortLabel: "Collab" },
  { id: "bio_link_story", label: "Bio Link & Story", shortLabel: "Bio & Story" },
];

function getDeliverableLabel(id: DeliverableType): string {
  return DELIVERABLES.find((d) => d.id === id)?.label || "Instagram Reel";
}

function getCreatorRateForDeliverable(c: CreatorCard, deliv: DeliverableType): number {
  if (c.rateCard && typeof c.rateCard[deliv] === "number" && c.rateCard[deliv] > 0) {
    return c.rateCard[deliv];
  }
  return c.price;
}
const STYLES: { id: CampaignDetails["promotionStyle"]; label: string; text: string }[] = [
  { id: "lyrics", label: "Lyrics / Page promotion", text: "Creator uses the provided audio and content only" },
  { id: "face_on_camera", label: "Face on camera", text: "Creator appears in the video" },
  { id: "direct_share", label: "Direct share", text: "Creator shares the file you provide" },
];
const STEP_CONFIG = [
  { full: "Creator Selection", short: "Creators" },
  { full: "Campaign Details", short: "Details" },
  { full: "Promotion Content", short: "Content" },
  { full: "Review & Launch", short: "Review" },
];
const STEPS = STEP_CONFIG.map((s) => s.full);
const DISCLOSURE = "Add #ad or the Instagram “Paid partnership” label.";

const emptyDetails: CampaignDetails = {
  title: "New Song / Brand Promo Campaign", 
  songUrl: "https://instagram.com/reels/sample", 
  description: "Promote brand audio / product on Instagram Reels across top creator channels.", 
  genre: "Music & Lifestyle", 
  language: "Hindi & English", 
  deliverable: "reel", 
  deadline: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
  cityIds: [], 
  accountsToMention: [], 
  requiredTags: ["#MingreePromotions"], 
  captionNote: "Check out this brand new release! Use official audio.", 
  disclosureInstructions: "#ad | Paid Partnership", 
  assetUrl: "", 
  assetFileName: "", 
  websiteUrl: "", 
  promotionStyle: "lyrics",
};

function Field({ id, label, required, hint, children }: { id: string; label: string; required?: boolean; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="text-sm font-semibold">{label}{required && <span className="text-primary"> *</span>}</label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function ChipInput({ id, values, onChange, placeholder, prefix = "" }: { id: string; values: string[]; onChange: (v: string[]) => void; placeholder: string; prefix?: string }) {
  const [v, setV] = useState("");
  const add = () => {
    const t = v.trim().replace(/^[@#]+/, "");
    if (t && !values.includes(prefix + t)) onChange([...values, prefix + t]);
    setV("");
  };
  return (
    <div>
      <Input id={id} value={v} placeholder={placeholder} onChange={(e) => setV(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(); } }} onBlur={add} />
      {values.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {values.map((x) => (
            <span key={x} className="inline-flex items-center gap-1 rounded-full border bg-muted/40 px-3 py-1 text-xs">
              {x}
              <button type="button" aria-label={`Remove ${x}`} onClick={() => onChange(values.filter((y) => y !== x))}></button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}

interface Props {
  api: ManualCampaignApi;
  onBack?: () => void;
  onAddMoney?: () => void;
  onCreated: (campaignId: number) => void;
}

export function ManualCampaignPage({ api, onBack, onAddMoney, onCreated }: Props) {
  const [step, setStep] = useState(0);
  const [d, setD] = useState<CampaignDetails>(emptyDetails);
  const set = <K extends keyof CampaignDetails>(k: K, v: CampaignDetails[K]) => setD((p) => ({ ...p, [k]: v }));

  const [selected, setSelected] = useState<Map<number, CreatorCard>>(new Map());
  const [customRates, setCustomRates] = useState<Record<number, number>>({});
  const [creatorDeliverables, setCreatorDeliverables] = useState<Record<number, DeliverableType>>({});
  const [editingRateCreatorId, setEditingRateCreatorId] = useState<number | null>(null);
  const [customRateInput, setCustomRateInput] = useState<string>("");

  // Reset selection
  const resetSelection = () => {
    setSelected(new Map());
    setCustomRates({});
    setCreatorDeliverables({});
    setEditingRateCreatorId(null);
    setBill(null);
  };
  const setDeliverable = (x: DeliverableType) => {
    set("deliverable", x);
    if (editingRateCreatorId !== null && !creatorDeliverables[editingRateCreatorId]) {
      const targetCreator =
        searchResults.find((c) => c.id === editingRateCreatorId) ||
        selected.get(editingRateCreatorId);
      if (targetCreator) {
        setCustomRateInput(String(getCreatorRateForDeliverable(targetCreator, x)));
      }
    }
    // Keep selected creators! Their prices will be updated in the bill preview for the new deliverable.
  };
  const setCreatorPackage = (creator: CreatorCard, deliv: DeliverableType) => {
    setCreatorDeliverables((prev) => ({ ...prev, [creator.id]: deliv }));
    // Clear stale custom offer if user switches package cleanly
    setCustomRates((prev) => {
      if (!prev[creator.id]) return prev;
      const next = { ...prev };
      delete next[creator.id];
      return next;
    });
    if (editingRateCreatorId === creator.id) {
      setCustomRateInput(String(getCreatorRateForDeliverable(creator, deliv)));
    }
  };
  const remove = (id: number) => {
    setSelected((p) => { const m = new Map(p); m.delete(id); return m; });
    setCustomRates((prev) => {
      if (!prev[id]) return prev;
      const next = { ...prev };
      delete next[id];
      return next;
    });
    setCreatorDeliverables((prev) => {
      if (!prev[id]) return prev;
      const next = { ...prev };
      delete next[id];
      return next;
    });
    if (editingRateCreatorId === id) setEditingRateCreatorId(null);
  };

  const openRateDialog = (creator: CreatorCard) => {
    const activeDeliv = creatorDeliverables[creator.id] || d.deliverable;
    const baseRate = getCreatorRateForDeliverable(creator, activeDeliv);
    setEditingRateCreatorId(creator.id);
    setCustomRateInput(customRates[creator.id] ? String(customRates[creator.id]) : String(baseRate));
  };

  const applyCustomRate = (creator: CreatorCard, amount: number) => {
    const clean = Math.max(100, Math.round(amount));
    setCustomRates((prev) => ({ ...prev, [creator.id]: clean }));
    // If not yet selected, also add the creator
    if (!selected.has(creator.id)) {
      setSelected((prev) => new Map(prev).set(creator.id, creator));
    }
    setEditingRateCreatorId(null);
    toast.success(`Proposed rate ₹${clean.toLocaleString("en-IN")} set for @${creator.username}`);
  };

  const resetCustomRate = (creatorId: number) => {
    setCustomRates((prev) => {
      const next = { ...prev };
      delete next[creatorId];
      return next;
    });
    if (editingRateCreatorId === creatorId) {
      setEditingRateCreatorId(null);
    }
    toast.info("Rate reset to creator's standard rate");
  };

  // Bill always comes from the server.
  const [bill, setBill] = useState<Bill | null>(null);
  const [billLoading, setBillLoading] = useState(false);
  const [billErr, setBillErr] = useState<string | null>(null);
  const creatorIds = useMemo(() => [...selected.keys()].sort((a, b) => a - b), [selected]);
  const refreshBill = useCallback(async () => {
    if (!creatorIds.length) { setBill(null); return; }
    setBillLoading(true); setBillErr(null);
    try {
      setBill(await api.previewBill({
        deliverable: d.deliverable,
        creatorIds,
        customRates: Object.keys(customRates).length > 0 ? customRates : undefined,
        creatorDeliverables: Object.keys(creatorDeliverables).length > 0 ? creatorDeliverables : undefined,
      }));
    }
    catch (e: any) { setBillErr(e?.message || "Could not calculate the bill"); setBill(null); }
    finally { setBillLoading(false); }
  }, [api, creatorIds, d.deliverable, customRates, creatorDeliverables]);
  useEffect(() => { const t = setTimeout(refreshBill, 250); return () => clearTimeout(t); }, [refreshBill]);

  // Live direct creator search state
  const [globalSearchQ, setGlobalSearchQ] = useState("");
  const [selectedCityFilter, setSelectedCityFilter] = useState<string>("all");
  const [activeSort, setActiveSort] = useState<NonNullable<CreatorSearchParams["sort"]>>("relevance");
  const [searchResults, setSearchResults] = useState<CreatorCard[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchErr, setSearchErr] = useState<string | null>(null);

  useEffect(() => {
    if (step !== 0) return;
    let active = true;
    setSearchLoading(true);
    setSearchErr(null);

    const timer = setTimeout(async () => {
      try {
        const res = await api.searchCreators({
          city: selectedCityFilter === "all" ? undefined : selectedCityFilter,
          cityIds: [],
          tierId: "all",
          deliverable: d.deliverable,
          q: globalSearchQ.trim() || undefined,
          sort: activeSort,
        });
        if (active) {
          setSearchResults(res.items || []);
        }
      } catch (e: any) {
        if (active) {
          setSearchErr(e?.message || "Could not load creators");
        }
      } finally {
        if (active) setSearchLoading(false);
      }
    }, 200);

    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [step, globalSearchQ, selectedCityFilter, activeSort, d.deliverable, api]);

  const toggleCreator = (creator: CreatorCard) => {
    setSelected((prev) => {
      const next = new Map(prev);
      if (next.has(creator.id)) {
        next.delete(creator.id);
      } else {
        next.set(creator.id, creator);
      }
      return next;
    });
  };

  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState<{ kind: "warn" | "error"; text: string } | null>(null);
  const launch = async () => {
    if (!bill) return;
    setSubmitting(true); setNotice(null);
    try {
      const r = await api.submit({
        details: d,
        creatorIds,
        customRates: Object.keys(customRates).length > 0 ? customRates : undefined,
        creatorDeliverables: Object.keys(creatorDeliverables).length > 0 ? creatorDeliverables : undefined,
        billId: bill.billId,
      });
      if (r.ok === true) return onCreated((r as { ok: true; campaignId: number }).campaignId);
      const f = r as Exclude<SubmitResult, { ok: true }>;
      if (f.reason === "bill_changed") { setBill(f.bill); setNotice({ kind: "warn", text: "A creator's rate changed. Check the new total below and press Launch again to confirm." }); }
      else if (f.reason === "insufficient_funds") { setBill(f.bill); setNotice({ kind: "error", text: "Your wallet balance is not enough for this total. Add money and try again." }); }
      else setNotice({ kind: "error", text: f.message });
    } catch (e: any) { setNotice({ kind: "error", text: e?.message || "Something went wrong. Nothing was charged." }); }
    finally { setSubmitting(false); }
  };

  const problems: string[][] = [
    [
      creatorIds.length === 0 && "Select at least one creator from the list",
    ].filter(Boolean) as string[],
    [
      !d.title.trim() && "Add a campaign title",
      !d.songUrl.trim() && "Add the song link",
      !d.description.trim() && "Add a short description",
      !d.deadline && "Pick a deadline",
    ].filter(Boolean) as string[],
    [!d.captionNote.trim() && "Add a caption note with the disclosure"].filter(Boolean) as string[],
    [
      creatorIds.length === 0 && "Select at least one creator from Step 1",
      billLoading && "Calculating bill...",
      !bill && creatorIds.length > 0 && !billLoading && "Unable to calculate bill",
      bill && bill.shortfall > 0 && `Wallet balance is lower than total (${inr(bill.shortfall)} shortfall)`,
    ].filter(Boolean) as string[],
  ];
  const stepOk = problems[step].length === 0;
  const today = new Date().toISOString().slice(0, 10);

  const handleStepClick = (targetStep: number) => {
    if (targetStep === step) return;
    if (targetStep < step) {
      setStep(targetStep);
      return;
    }
    // Check if earlier steps have problems
    for (let i = 0; i < targetStep; i++) {
      if (problems[i].length > 0) {
        toast.error(`Please complete "${STEPS[i]}" first: ${problems[i][0]}`);
        setStep(i);
        return;
      }
    }
    setStep(targetStep);
  };

  const perCreator = new Map(bill?.lines.map((l) => [l.creatorId, l]) ?? []);

  return (
    <div className="w-full max-w-5xl mx-auto p-4 sm:p-6 space-y-6 [&_section]:min-w-0 overflow-x-hidden">
      {/* Stepper */}
      <div className="flex items-center justify-between gap-2 sm:gap-4 pb-3 border-b border-border/70 flex-wrap sm:flex-nowrap">
        {onBack && (
          <Button
            variant="outline"
            size="sm"
            onClick={onBack}
            className="shrink-0 h-8 px-2.5 text-xs font-semibold rounded-lg gap-1.5 cursor-pointer bg-background hover:bg-muted"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back</span>
          </Button>
        )}

        <ol className="flex flex-1 min-w-0 items-center justify-center gap-1.5 sm:gap-3 overflow-x-auto no-scrollbar py-0.5" aria-label="Progress">
          {STEP_CONFIG.map((s, i) => {
            const isStepDone = problems[i].length === 0 && (i < step || (i === 3 && step === 3 && selected.size > 0 && !!bill && bill.shortfall <= 0));
            const isCurrent = i === step;
            return (
              <li key={s.full} className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => handleStepClick(i)}
                  className="flex items-center gap-1.5 cursor-pointer hover:opacity-90 transition rounded-full focus:outline-none"
                >
                  <span
                    className={cn(
                      "h-6 w-6 sm:h-7 sm:w-7 rounded-full text-xs font-bold flex items-center justify-center border transition-all shrink-0",
                      isStepDone
                        ? "bg-primary text-primary-foreground border-primary"
                        : isCurrent
                        ? "border-primary text-primary bg-primary/10 ring-2 ring-primary/20"
                        : "text-muted-foreground border-border bg-muted/40"
                    )}
                  >
                    {isStepDone ? "✓" : i + 1}
                  </span>
                  <span
                    className={cn(
                      "text-xs sm:text-sm font-medium whitespace-nowrap",
                      isCurrent
                        ? "font-bold text-primary inline"
                        : "text-muted-foreground hidden lg:inline"
                    )}
                  >
                    {isCurrent ? s.full : s.short}
                  </span>
                </button>
                {i < STEP_CONFIG.length - 1 && (
                  <span className="text-border/80 text-xs hidden sm:inline select-none">&rarr;</span>
                )}
              </li>
            );
          })}
        </ol>

        <div className="shrink-0 hidden sm:flex items-center">
          <span className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground bg-muted/60 px-2.5 py-1 rounded-full border border-border/60">
            Step {step + 1} of 4
          </span>
        </div>
      </div>

      {/* Step 2: Campaign Details */}
      {step === 1 && (
        <section className="rounded-2xl border bg-card p-5 sm:p-6 space-y-5">
          <header><h2 className="text-xl font-bold">Campaign Details</h2><p className="text-sm text-muted-foreground">Tell us about your song and where it should be promoted.</p></header>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="title" label="Campaign title" required><Input id="title" value={d.title} onChange={(e) => set("title", e.target.value)} placeholder="Summer single promo" /></Field>
            <Field id="song" label="Song link" required hint="Instagram audio, Reel or Spotify link"><Input id="song" value={d.songUrl} onChange={(e) => set("songUrl", e.target.value)} placeholder="https://" /></Field>
          </div>
          <Field id="desc" label="Description" required hint="What should creators do? Mention the vibe, hook and anything to avoid.">
            <Textarea id="desc" value={d.description} onChange={(e) => set("description", e.target.value)} rows={4} />
          </Field>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="genre" label="Genre">
              <Select value={d.genre} onValueChange={(v) => set("genre", v)}>
                <SelectTrigger className="w-full h-10 rounded-xl" data-testid="select-genre">
                  <SelectValue placeholder="Select genre..." />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {INDIAN_GENRES.map((genre) => (
                    <SelectItem key={genre} value={genre}>
                      {genre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field id="deadline" label="Post by (deadline)" required><Input id="deadline" type="date" min={today} value={d.deadline} onChange={(e) => set("deadline", e.target.value)} /></Field>
          </div>
          <Field id="accounts" label="Accounts to mention (optional)">
            <ChipInput id="accounts" values={d.accountsToMention} onChange={(v) => set("accountsToMention", v)} placeholder="@youraccount, press Enter" prefix="@" />
          </Field>

          <Field id="captionNote" label="Mandatory Caption Note" required hint="Caption copy that creators must include in their Reel">
            <Textarea id="captionNote" value={d.captionNote} onChange={(e) => set("captionNote", e.target.value)} rows={3} placeholder="#ad | Check out..." />
          </Field>
          <Field id="disclosure" label="FTC / Disclosure Instructions">
            <Input id="disclosure" value={d.disclosureInstructions || ""} onChange={(e) => set("disclosureInstructions", e.target.value)} placeholder="#ad | Paid Partnership" />
          </Field>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field id="websiteUrl" label="Website / Landing Page Link (optional)" hint="Link for creators to promote in bio/caption">
              <Input id="websiteUrl" value={d.websiteUrl || ""} onChange={(e) => set("websiteUrl", e.target.value)} placeholder="https://yourbrand.com" />
            </Field>
            <Field id="asset" label="Promotional Video / Asset File (optional)" hint="Upload video or banner for creators to download and post">
              <div className="flex items-center gap-2">
                <Input
                  type="file"
                  id="manual-asset-upload"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const fd = new FormData();
                      fd.append("file", file);
                      try {
                        const res = await fetch("/api/upload", { method: "POST", body: fd });
                        if (res.ok) {
                          const data = await res.json();
                          set("assetUrl", data.url);
                          set("assetFileName", data.fileName || file.name);
                          toast.success("File uploaded successfully!");
                        } else {
                          toast.error("Upload failed");
                        }
                      } catch {
                        toast.error("Upload failed");
                      }
                    }
                  }}
                />
                <label
                  htmlFor="manual-asset-upload"
                  className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dashed border-primary/50 bg-primary/5 hover:bg-primary/10 text-xs font-semibold cursor-pointer text-primary transition"
                >
                  
                  {d.assetFileName || (d.assetUrl ? "Change File" : "Upload Video / File")}
                </label>
                {d.assetUrl && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="h-10 w-10 text-rose-500 hover:bg-rose-50 shrink-0"
                    onClick={() => { set("assetUrl", ""); set("assetFileName", ""); }}
                  >
                    
                  </Button>
                )}
              </div>
            </Field>
          </div>
        </section>
      )}

      {/* Step 1: Select Creators */}
      {step === 0 && (
        <section className="rounded-2xl border bg-card p-5 sm:p-7 space-y-6">
          <header className="text-center space-y-1.5 max-w-2xl mx-auto">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">Select Creators</h2>
            <p className="text-xs sm:text-sm text-muted-foreground">
              Search any creator directly by name or @handle. Add verified creators to your campaign with transparent rates.
            </p>
          </header>

          <div className="w-full max-w-2xl mx-auto space-y-3 relative">
            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="relative flex items-center group flex-1">
                <span className="absolute left-4 text-muted-foreground text-lg pointer-events-none group-focus-within:text-primary transition-colors">
                  🔍
                </span>
                <input
                  id="global-creator-search"
                  type="text"
                  value={globalSearchQ}
                  onChange={(e) => setGlobalSearchQ(e.target.value)}
                  placeholder="Search creator by name or @handle... (e.g. judge, priya)"
                  className="w-full h-12 pl-12 pr-10 rounded-xl border-2 border-border/80 bg-background shadow-xs hover:border-primary/60 focus:border-primary text-sm transition-all outline-none"
                />
                {globalSearchQ && (
                  <button
                    type="button"
                    onClick={() => setGlobalSearchQ("")}
                    className="absolute right-3 h-6 w-6 rounded-full bg-muted flex items-center justify-center text-xs text-muted-foreground hover:text-foreground cursor-pointer transition"
                    title="Clear search"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* City Filter Dropdown */}
              <select
                value={selectedCityFilter}
                onChange={(e) => setSelectedCityFilter(e.target.value)}
                className="h-12 px-3 rounded-xl border-2 border-border/80 bg-background text-sm font-medium text-foreground outline-none hover:border-primary/60 focus:border-primary shrink-0"
                aria-label="Filter creators by city"
              >
                <option value="all">📍 All Cities (India)</option>
                {CITIES_BY_COUNTRY.IN.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* Google-Style Floating Live Suggestion Dropdown */}
            {globalSearchQ.trim().length > 0 && (
              <div className="absolute top-full left-0 right-0 z-50 mt-2 bg-card border rounded-2xl shadow-2xl overflow-hidden divide-y divide-border/40 max-h-[380px] overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="px-4 py-2 bg-muted/40 text-[11px] font-bold tracking-wider text-muted-foreground flex items-center justify-between uppercase">
                  <span>Creators</span>
                  <span>{searchResults.length} match{searchResults.length === 1 ? "" : "es"}</span>
                </div>

                {searchLoading && (
                  <div className="p-4 text-center text-xs text-muted-foreground animate-pulse">
                    Searching creators...
                  </div>
                )}

                {!searchLoading && searchResults.length === 0 && (
                  <div className="p-5 text-center text-xs text-muted-foreground space-y-1">
                    <p className="font-semibold text-foreground">No creator found matching “{globalSearchQ}”</p>
                    <p className="text-[11px]">Try searching by handle or name.</p>
                  </div>
                )}

                {!searchLoading && searchResults.map((c) => {
                  const isChosen = selected.has(c.id);
                  return (
                    <div
                      key={c.id}
                      className="p-3 flex items-center justify-between gap-3 hover:bg-muted/30 transition cursor-pointer"
                      onClick={() => toggleCreator(c)}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <CreatorAvatar
                          avatarUrl={c.avatarUrl}
                          displayName={c.accountName || c.displayName}
                          username={c.username}
                          size={40}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 truncate">
                            <span className="font-bold text-sm text-foreground truncate">
                              {c.accountName || c.displayName || `@${c.username}`}
                            </span>
                            <span className="text-xs text-muted-foreground font-medium">@{c.username}</span>
                            {c.isRealRegisteredCreator && (
                              <span className="text-[9px] font-bold bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 px-1 py-0.2 rounded shrink-0">
                                Registered
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-muted-foreground truncate flex items-center gap-1.5 flex-wrap">
                            <span>Instagram Creator</span>
                            {c.city?.name && <span>· {c.city.name}</span>}
                            <span>·</span>
                            <span className="text-sky-600 font-semibold">📡 {c.reach ? compact(c.reach) : (c.followers > 0 ? compact(Math.round(c.followers * 2.2)) : "—")} reach</span>
                            <span>·</span>
                            <span className="text-foreground font-medium">👁️ {c.medianViews ? compact(c.medianViews) : "—"} views</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="text-right">
                          {(() => {
                            const activeDeliv = creatorDeliverables[c.id] || d.deliverable;
                            const activePrice = getCreatorRateForDeliverable(c, activeDeliv);
                            if (customRates[c.id]) {
                              return (
                                <div>
                                  <div className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                                    {inr(customRates[c.id])}
                                  </div>
                                  <div className="text-[10px] text-muted-foreground line-through tabular-nums">
                                    {inr(activePrice)}
                                  </div>
                                </div>
                              );
                            }
                            return (
                              <div>
                                <div className="text-sm font-bold tabular-nums text-foreground">{inr(activePrice)}</div>
                                <div className="text-[10px] text-muted-foreground">{DELIVERABLES.find((x) => x.id === activeDeliv)?.shortLabel}</div>
                              </div>
                            );
                          })()}
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            openRateDialog(c);
                          }}
                          className={cn(
                            "h-8 px-2.5 text-xs font-semibold rounded-xl transition-all",
                            customRates[c.id]
                              ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                              : "text-muted-foreground hover:text-foreground"
                          )}
                          title="Offer custom rate"
                        >
                          {customRates[c.id] ? "✏️ Offer" : "💬 Custom Rate"}
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant={isChosen ? "default" : "outline"}
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleCreator(c);
                          }}
                          className={cn(
                            "h-8 px-3 text-xs font-semibold rounded-xl transition-all",
                            isChosen
                              ? "bg-primary text-primary-foreground shadow-xs"
                              : "border-primary text-primary hover:bg-primary/10"
                          )}
                        >
                          {isChosen ? "✓ Added" : "+ Add"}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Creators Drawer / Live Results for Direct Search */}
          <div className="space-y-3 rounded-2xl border bg-muted/10 p-4 sm:p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 flex-wrap min-w-0">
                <h3 className="font-bold text-sm text-foreground">
                  {globalSearchQ.trim()
                    ? `Matching Creators for “${globalSearchQ.trim()}”`
                    : "Available Creators"}
                </h3>
                <span className="text-xs text-muted-foreground font-medium px-2 py-0.5 rounded-full bg-muted border border-border/60 shrink-0">
                  {searchResults.length} {searchResults.length === 1 ? "creator" : "creators"}
                </span>
                {!globalSearchQ.trim() && (
                  <span className="text-[11px] font-medium text-primary bg-primary/10 border border-primary/20 px-2 py-0.5 rounded-md shrink-0">
                    Ranked by Reach &amp; Views
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs text-muted-foreground font-medium hidden sm:inline">Sort:</span>
                <select
                  value={activeSort}
                  onChange={(e) => setActiveSort(e.target.value as any)}
                  className="h-8 rounded-lg border bg-background px-2.5 text-xs font-semibold text-foreground focus:ring-1 focus:ring-primary outline-none max-w-full cursor-pointer"
                  aria-label="Sort creators"
                >
                  <option value="relevance">Top Reach &amp; Views (Default)</option>
                  <option value="reach_desc">Highest Reach</option>
                  <option value="views_desc">Most Reel Views</option>
                  <option value="engagement_desc">High Engagement</option>
                  <option value="followers_desc">Followers (High to Low)</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                </select>
                {searchLoading && <span className="text-xs text-muted-foreground animate-pulse">Updating...</span>}
              </div>
            </div>

            {searchErr && <p className="text-sm text-destructive">{searchErr}</p>}

            {!searchLoading && searchResults.length === 0 && (
              <div className="p-8 text-center text-sm text-muted-foreground space-y-2">
                {globalSearchQ.trim() ? (
                  <>
                    <p>No creators match “{globalSearchQ.trim()}”.</p>
                    <Button variant="outline" size="sm" onClick={() => setGlobalSearchQ("")}>
                      Clear Search
                    </Button>
                  </>
                ) : (
                  <>
                    <p className="font-medium text-foreground">No active verified creators found.</p>
                    <p className="text-xs text-muted-foreground">
                      Creators will automatically appear in this marketplace once they connect and verify their Instagram accounts.
                    </p>
                  </>
                )}
              </div>
            )}

            {/* Grid of Creators */}
            <div className="grid gap-3.5 grid-cols-1 min-[920px]:grid-cols-2 xl:grid-cols-3 max-h-[680px] overflow-y-auto p-1">
              {searchResults.map((c) => {
                const isChosen = selected.has(c.id);
                const reachVal = c.reach || Math.round(c.followers * 2.2);
                const creatorName = c.accountName || c.displayName || `@${c.username}`;
                const activeDeliv = creatorDeliverables[c.id] || d.deliverable;
                const activeRate = getCreatorRateForDeliverable(c, activeDeliv);
                const activeLabel = getDeliverableLabel(activeDeliv);
                return (
                  <div
                    key={c.id}
                    className={cn(
                      "rounded-xl border p-3.5 flex flex-col justify-between transition-all bg-card hover:shadow-sm",
                      isChosen ? "border-primary ring-2 ring-primary/20 bg-primary/[0.02]" : "border-border hover:border-primary/50"
                    )}
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center gap-3">
                        <CreatorAvatar
                          avatarUrl={c.avatarUrl}
                          displayName={creatorName}
                          username={c.username}
                          size={48}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="font-bold text-sm text-foreground truncate leading-tight">
                            {creatorName}
                          </div>
                          <div className="flex items-center gap-1.5 min-w-0 mt-0.5">
                            <span className="text-xs text-muted-foreground font-medium truncate">@{c.username}</span>
                            {c.igVerifiedBadge && (
                              <span className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-sky-500 text-white text-[9px] shrink-0" title="Verified Instagram Creator">
                                ✓
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                            <span className="inline-flex items-center gap-1 text-[11px]">
                              <span className="w-1.5 h-1.5 rounded-full bg-pink-500 shrink-0" />
                              Instagram Creator
                            </span>
                            {c.city?.name && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="truncate">{c.city.name}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* 4 Instagram Performance & Insights Stats */}
                      <div className="grid grid-cols-4 gap-1 rounded-xl bg-muted/30 p-1.5 text-center text-xs border border-border/50">
                        <div className="bg-background rounded-lg py-1 px-0.5 border border-border/40 shadow-2xs overflow-hidden">
                          <div className="font-bold tabular-nums text-foreground text-xs">{reachVal ? compact(reachVal) : "—"}</div>
                          <div className="text-[8px] text-muted-foreground uppercase font-semibold tracking-tight truncate">Reach</div>
                        </div>
                        <div className="bg-background rounded-lg py-1 px-0.5 border border-border/40 shadow-2xs overflow-hidden">
                          <div className="font-bold tabular-nums text-foreground text-xs">{c.medianViews != null && c.medianViews > 0 ? compact(c.medianViews) : "—"}</div>
                          <div className="text-[8px] text-muted-foreground uppercase font-semibold tracking-tight truncate">Views</div>
                        </div>
                        <div className="bg-background rounded-lg py-1 px-0.5 border border-border/40 shadow-2xs overflow-hidden">
                          <div className="font-bold tabular-nums text-foreground text-xs">{c.followers > 0 ? compact(c.followers) : "—"}</div>
                          <div className="text-[8px] text-muted-foreground uppercase font-semibold tracking-tight truncate">Fol.</div>
                        </div>
                        <div className="bg-background rounded-lg py-1 px-0.5 border border-border/40 shadow-2xs overflow-hidden">
                          <div className="font-bold tabular-nums text-foreground text-xs">{c.engagementRate != null && c.engagementRate > 0 ? `${c.engagementRate}%` : "—"}</div>
                          <div className="text-[8px] text-muted-foreground uppercase font-semibold tracking-tight truncate">Eng.</div>
                        </div>
                      </div>

                      {/* Instagram Insights Tag */}
                      {c.indiaAudiencePct ? (
                        <div className="flex items-center justify-end text-[11px] text-muted-foreground px-0.5">
                          <span className="text-[10px] text-muted-foreground font-medium">{c.indiaAudiencePct}% India</span>
                        </div>
                      ) : null}

                      {/* Creator's 4-Tier Rate Card */}
                      <div className="space-y-1.5 pt-1">
                        <div className="flex items-center justify-between px-0.5">
                          <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                            Creator Rate Card
                          </span>
                          {c.hasCustomRateCard && (
                            <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                              ✓ Verified Rates
                            </span>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-1.5">
                          {DELIVERABLES.map((item) => {
                            const itemPrice = getCreatorRateForDeliverable(c, item.id);
                            const isSelectedPkg = activeDeliv === item.id;
                            return (
                              <button
                                key={item.id}
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setCreatorPackage(c, item.id);
                                }}
                                className={cn(
                                  "flex flex-col items-start justify-between rounded-lg border px-2 py-1.5 text-left transition-all cursor-pointer",
                                  isSelectedPkg
                                    ? "border-primary bg-primary/10 ring-1 ring-primary/30"
                                    : "border-border/70 bg-muted/20 hover:border-primary/40 hover:bg-muted/40"
                                )}
                              >
                                <span
                                  className={cn(
                                    "text-[10px] font-semibold leading-tight truncate w-full",
                                    isSelectedPkg ? "text-primary" : "text-muted-foreground"
                                  )}
                                >
                                  {item.label}
                                </span>
                                <span
                                  className={cn(
                                    "text-xs font-extrabold tabular-nums mt-0.5",
                                    isSelectedPkg ? "text-primary" : "text-foreground"
                                  )}
                                >
                                  {inr(itemPrice)}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Rate and Custom Negotiation Offer Button */}
                    <div className="mt-3 pt-2.5 border-t space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          {customRates[c.id] ? (
                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="font-extrabold text-sm tabular-nums text-emerald-600 dark:text-emerald-400">
                                  {inr(customRates[c.id])}
                                </span>
                                <span className="text-[10px] font-semibold line-through text-muted-foreground tabular-nums">
                                  {inr(activeRate)}
                                </span>
                              </div>
                              <div className="text-[10px] font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                                <span>⚡ Your Offer ({activeLabel})</span>
                              </div>
                            </div>
                          ) : (
                            <div>
                              <div className="font-bold text-sm tabular-nums text-foreground">{inr(activeRate)}</div>
                              <div className="text-[10px] text-muted-foreground">{activeLabel}</div>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {/* Offer / Negotiate Rate Button */}
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (editingRateCreatorId === c.id) {
                                setEditingRateCreatorId(null);
                              } else {
                                openRateDialog(c);
                              }
                            }}
                            className={cn(
                              "h-8 px-2.5 text-xs font-semibold rounded-lg transition-all",
                              customRates[c.id]
                                ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/20"
                                : "border-muted-foreground/30 text-foreground hover:bg-muted"
                            )}
                            title="Set your custom offered rate for this creator"
                          >
                            {customRates[c.id] ? "✏️ Offer" : "💬 Custom Rate"}
                          </Button>

                          <Button
                            type="button"
                            size="sm"
                            variant={isChosen ? "default" : "outline"}
                            onClick={() => toggleCreator(c)}
                            className={cn(
                              "h-8 px-3 text-xs font-semibold rounded-lg transition-all",
                              isChosen
                                ? "bg-primary text-primary-foreground shadow-xs"
                                : "border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                            )}
                          >
                            {isChosen ? "✓ Added" : "+ Add"}
                          </Button>
                        </div>
                      </div>

                      {/* Inline Custom Rate Offer Input Box */}
                      {editingRateCreatorId === c.id && (
                        <div className="rounded-xl border border-primary/40 bg-primary/5 p-3 space-y-2 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-foreground">Propose Offer for @{c.username}</span>
                            <span className="text-[10px] text-muted-foreground">Standard ({activeLabel}): {inr(activeRate)}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="relative flex-1">
                              <span className="absolute left-2.5 top-1/2 -translate-y-1/2 font-bold text-muted-foreground">₹</span>
                              <Input
                                type="number"
                                min={100}
                                value={customRateInput}
                                onChange={(e) => setCustomRateInput(e.target.value)}
                                placeholder={String(activeRate)}
                                className="h-8 pl-6 pr-2 text-xs font-bold bg-background rounded-lg"
                                autoFocus
                                onKeyDown={(e) => {
                                  if (e.key === "Enter") {
                                    e.preventDefault();
                                    const val = Number(customRateInput);
                                    if (val > 0) applyCustomRate(c, val);
                                  }
                                }}
                              />
                            </div>
                            <Button
                              type="button"
                              size="sm"
                              onClick={() => {
                                const val = Number(customRateInput);
                                if (val > 0) applyCustomRate(c, val);
                                else toast.error("Enter a valid offer amount in ₹");
                              }}
                              className="h-8 px-3 text-xs font-bold rounded-lg bg-primary text-primary-foreground shadow-2xs"
                            >
                              Apply
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              variant="ghost"
                              onClick={() => setEditingRateCreatorId(null)}
                              className="h-8 px-2 text-xs text-muted-foreground hover:text-foreground"
                            >
                              ✕
                            </Button>
                          </div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-[10px] text-muted-foreground font-medium">Quick:</span>
                            {[
                              { label: "-10%", amt: Math.round(activeRate * 0.9) },
                              { label: "-20%", amt: Math.round(activeRate * 0.8) },
                              { label: "₹1,000", amt: 1000 },
                              { label: "₹1,500", amt: 1500 },
                            ].filter((preset, idx, arr) => preset.amt > 0 && arr.findIndex(x => x.amt === preset.amt) === idx).map((preset) => (
                              <button
                                key={preset.label}
                                type="button"
                                onClick={() => setCustomRateInput(String(preset.amt))}
                                className="text-[10px] px-2 py-0.5 rounded-md border border-border bg-background hover:bg-muted font-medium transition cursor-pointer"
                              >
                                {preset.label} ({inr(preset.amt)})
                              </button>
                            ))}
                            {customRates[c.id] && (
                              <button
                                type="button"
                                onClick={() => resetCustomRate(c.id)}
                                className="text-[10px] px-2 py-0.5 rounded-md text-destructive hover:bg-destructive/10 font-medium transition cursor-pointer ml-auto"
                              >
                                Reset to Base
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Selected Creators Stack - Right below as requested */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base flex items-center gap-2">
                <span>Selected Creators</span>
                <span className="inline-flex items-center justify-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-primary text-primary-foreground">
                  {selected.size}
                </span>
              </h3>
              {selected.size > 0 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={resetSelection}
                  className="text-xs text-muted-foreground hover:text-destructive h-8"
                >
                  Clear all
                </Button>
              )}
            </div>

            {selected.size === 0 ? (
              <div className="text-center rounded-2xl border-2 border-dashed p-7 bg-muted/5 space-y-1">
                <p className="text-sm font-medium">No creators selected yet</p>
                <p className="text-xs text-muted-foreground">
                  Use the search bar above to browse and pick creators for your campaign.
                </p>
              </div>
            ) : (
              <div className="divide-y rounded-xl border bg-card overflow-hidden">
                {[...selected.values()].map((c) => {
                  const activeDeliv = creatorDeliverables[c.id] || d.deliverable;
                  const activePrice = getCreatorRateForDeliverable(c, activeDeliv);
                  const activeLabel = getDeliverableLabel(activeDeliv);
                  return (
                  <div key={c.id} className="flex items-center gap-3 p-3.5 hover:bg-muted/10 transition flex-wrap sm:flex-nowrap">
                    <CreatorAvatar
                      avatarUrl={c.avatarUrl}
                      displayName={c.accountName || c.displayName}
                      username={c.username}
                      size={36}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold truncate flex items-center gap-1.5 flex-wrap">
                        <span className="text-foreground font-bold">{c.accountName || c.displayName || `@${c.username}`}</span>
                        <span className="text-xs text-muted-foreground font-normal">(@{c.username})</span>
                        {c.isRealRegisteredCreator && (
                          <span className="text-[9px] font-semibold bg-emerald-500/10 text-emerald-600 px-1 py-0.2 rounded shrink-0">
                            Registered
                          </span>
                        )}
                        {customRates[c.id] && (
                          <span className="text-[9px] font-bold bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/30 px-1.5 py-0.2 rounded-full">
                            Custom Offer
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground truncate flex items-center gap-1.5 flex-wrap">
                        <span>Instagram Creator · {compact(c.followers)} followers {c.city?.name ? `· ${c.city.name}` : ""}</span>
                        <span className="text-primary font-semibold">· {activeLabel}</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      {customRates[c.id] ? (
                        <div>
                          <div className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 tabular-nums">
                            {inr(customRates[c.id])}
                          </div>
                          <div className="text-[10px] text-muted-foreground line-through tabular-nums">
                            Base {inr(activePrice)}
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="text-sm font-bold tabular-nums">{inr(activePrice)}</div>
                          <div className="text-[10px] text-muted-foreground">{activeLabel}</div>
                        </div>
                      )}
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() => openRateDialog(c)}
                      className={cn(
                        "h-8 px-2 text-xs rounded-lg transition",
                        customRates[c.id] ? "text-emerald-600 font-bold hover:bg-emerald-500/10" : "text-muted-foreground hover:text-foreground"
                      )}
                      title="Propose / edit offer rate"
                    >
                      {customRates[c.id] ? "✏️ Edit" : "💬 Offer"}
                    </Button>
                    <button
                      type="button"
                      aria-label={`Remove ${c.username}`}
                      onClick={() => remove(c.id)}
                      className="h-8 w-8 rounded-full flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition cursor-pointer"
                      title="Remove creator"
                    >
                      ✕
                    </button>
                  </div>
                  );
                })}
              </div>
            )}

            {/* Bill summary right underneath selected creators */}
            <BillCard bill={bill} loading={billLoading} error={billErr} count={selected.size} />
          </div>
        </section>
      )}

      {/* Step 3 */}
      {step === 2 && (
        <section className="rounded-2xl border bg-card p-5 sm:p-6 space-y-5">
          <header><h2 className="text-xl font-bold">Promotion Content</h2><p className="text-sm text-muted-foreground">Tell creators exactly what the post must contain. You will approve the post against these rules.</p></header>
          
          <div className="space-y-1.5">
            <div className="text-sm font-semibold">Content type <span className="text-primary">*</span></div>
            <div className="flex flex-wrap gap-2" role="radiogroup" aria-label="Content type">
              {DELIVERABLES.map((x) => (
                <button
                  key={x.id}
                  type="button"
                  role="radio"
                  aria-checked={d.deliverable === x.id}
                  onClick={() => setDeliverable(x.id)}
                  className={cn(
                    "h-10 px-4 rounded-xl border text-sm font-medium transition cursor-pointer",
                    d.deliverable === x.id ? "border-primary bg-primary/10 text-primary font-semibold" : "hover:border-primary/50"
                  )}
                >
                  {x.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="text-sm font-semibold">Promotion style</div>
            <div className="grid sm:grid-cols-3 gap-3" role="radiogroup" aria-label="Promotion style">
              {STYLES.map((s) => (
                <button key={s.id} type="button" role="radio" aria-checked={d.promotionStyle === s.id} onClick={() => set("promotionStyle", s.id)}
                  className={cn("rounded-xl border p-3 text-left", d.promotionStyle === s.id ? "border-primary bg-primary/5" : "hover:border-primary/50")}>
                  <div className="text-sm font-semibold">{s.label}</div>
                  <div className="text-xs text-muted-foreground">{s.text}</div>
                </button>
              ))}
            </div>
          </div>
          <Field id="tags" label="Required hashtags / tags" hint="Creators must include these. Press Enter to add.">
            <ChipInput id="tags" values={d.requiredTags} onChange={(v) => set("requiredTags", v)} placeholder="#yoursong" prefix="#" />
          </Field>
          <Field id="note" label="Caption note" required hint="Always keep the paid-promotion disclosure.">
            <Textarea id="note" value={d.captionNote} onChange={(e) => set("captionNote", e.target.value)} rows={3} />
          </Field>
        </section>
      )}

      {/* Step 4 */}
      {step === 3 && (
        <section className="rounded-2xl border bg-card p-5 sm:p-6 space-y-5">
          <header><h2 className="text-xl font-bold">Review &amp; Launch</h2><p className="text-sm text-muted-foreground">The total is taken from your wallet and held safely until each creator’s post is approved.</p></header>
          <dl className="grid sm:grid-cols-2 gap-x-6 gap-y-2 text-sm">
            <div className="flex justify-between gap-3 min-w-0"><dt className="text-muted-foreground">Campaign</dt><dd className="font-medium text-right truncate min-w-0">{d.title}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Content type</dt><dd className="font-medium">{DELIVERABLES.find((x) => x.id === d.deliverable)?.label}</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Selection</dt><dd className="font-medium text-right">Direct Creator Pick ({selected.size})</dd></div>
            <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Post by</dt><dd className="font-medium">{d.deadline}</dd></div>
          </dl>
          {notice && (
            <div role="alert" className={cn("rounded-xl border p-3 text-sm flex gap-2", notice.kind === "warn" ? "border-amber-300 bg-amber-50 text-amber-900" : "border-destructive/40 bg-destructive/5 text-destructive")}>
               <span>{notice.text}</span>
            </div>
          )}

          {selected.size === 0 ? (
            <div className="rounded-2xl border-2 border-dashed border-amber-500/30 p-8 text-center bg-amber-500/5 space-y-3">
              <div className="w-12 h-12 rounded-full bg-amber-500/10 text-amber-600 flex items-center justify-center mx-auto text-xl">
                ⚠️
              </div>
              <h3 className="font-bold text-base text-foreground">No Creators Selected</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                You must select at least one creator from Step 1 before calculating the bill and launching your campaign.
              </p>
              <div className="pt-2">
                <Button
                  type="button"
                  onClick={() => setStep(0)}
                  className="rounded-xl font-semibold cursor-pointer"
                >
                  ← Go to Step 1 &amp; Pick Creators
                </Button>
              </div>
            </div>
          ) : (
            <>
              <div className="rounded-xl border overflow-x-auto">
                <table className="w-full text-sm min-w-[480px]">
                  <thead className="bg-muted/40 text-xs text-muted-foreground"><tr>
                    <th className="text-left p-3 font-medium">Creator</th><th className="text-right p-3 font-medium">Price</th><th className="text-right p-3 font-medium">Mingree fee</th><th className="text-right p-3 font-medium">You pay</th>
                  </tr></thead>
                  <tbody className="divide-y">
                    {[...selected.values()].map((c) => {
                      const l = perCreator.get(c.id);
                      const activeDeliv = l?.deliverable || creatorDeliverables[c.id] || d.deliverable;
                      const activeLabel = getDeliverableLabel(activeDeliv);
                      const standardPrice = getCreatorRateForDeliverable(c, activeDeliv);
                      const hasCustom = Boolean(customRates[c.id]);
                      const linePrice = l?.price ?? (hasCustom ? customRates[c.id] : standardPrice);
                      return (
                        <tr key={c.id}>
                          <td className="p-3 font-medium">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-foreground">{c.accountName || c.displayName || `@${c.username}`}</span>
                              <span className="text-xs text-muted-foreground">(@{c.username})</span>
                              <span className="text-[10px] font-semibold bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-md">
                                {activeLabel}
                              </span>
                              {hasCustom && (
                                <span className="text-[10px] font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                                  Custom Offer (Negotiating)
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-3 text-right tabular-nums">
                            {hasCustom ? (
                              <div>
                                <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
                                  {inr(linePrice)}
                                </span>
                                <span className="text-[10px] text-muted-foreground line-through ml-1.5">
                                  {inr(standardPrice)}
                                </span>
                              </div>
                            ) : (
                              inr(linePrice)
                            )}
                          </td>
                          <td className="p-3 text-right tabular-nums">{l ? inr(l.feeArtist) : "—"}</td>
                          <td className="p-3 text-right tabular-nums font-medium">{l ? inr(l.artistCost) : "—"}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <BillCard bill={bill} loading={billLoading} error={billErr} count={selected.size} />
              {bill && bill.shortfall > 0 && (
                <div className="flex items-center justify-between gap-3 rounded-xl border border-primary/40 bg-primary/5 p-3 text-sm">
                  <span>You need {inr(bill.shortfall)} more in your wallet.</span>
                  {onAddMoney && <Button size="sm" onClick={onAddMoney}> Add money</Button>}
                </div>
              )}
            </>
          )}
        </section>
      )}

      {/* Footer nav */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
        <Button
          variant="outline"
          disabled={step === 0}
          onClick={() => setStep((s) => s - 1)}
          className="shrink-0 h-9 px-4 text-xs font-semibold rounded-xl cursor-pointer"
        >
          Previous
        </Button>
        <div className="flex items-center justify-between sm:justify-end gap-3 flex-wrap">
          {!stepOk && (
            <span className="text-xs text-muted-foreground font-medium text-left sm:text-right max-w-xs">
              {problems[step][0]}
            </span>
          )}
          {step < 3 ? (
            <Button
              disabled={!stepOk}
              className="shrink-0 h-9 px-5 text-xs font-semibold rounded-xl cursor-pointer"
              onClick={() => {
                if (problems[step].length > 0) {
                  toast.error(problems[step][0]);
                  return;
                }
                setStep((s) => s + 1);
              }}
            >
              Next
            </Button>
          ) : (
            <Button
              disabled={!stepOk || submitting || billLoading || selected.size === 0}
              onClick={launch}
              className="shrink-0 h-9 px-5 text-xs font-semibold rounded-xl cursor-pointer"
            >
              {submitting ? "Launching..." : "Launch campaign"}
              {bill ? ` · ${inr(bill.total)}` : ""}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function BillCard({ bill, loading, error, count }: { bill: Bill | null; loading: boolean; error: string | null; count: number }) {
  if (count === 0) return null;
  return (
    <div className="rounded-xl border bg-muted/20 p-4 space-y-1.5 text-sm" aria-live="polite">
      <div className="flex items-center justify-between"><h4 className="font-semibold">Your bill</h4>{loading && <span className="text-xs text-muted-foreground">Calculating...</span>}</div>
      {error && <p className="text-destructive">{error}</p>}
      {bill && (
        <>
          <Row l={`Creator prices (${bill.lines.length})`} v={inr(bill.subtotal)} />
          <Row l="Mingree fee (GST included)" v={inr(bill.feeTotal)} />
          <div className="border-t pt-2 mt-2 flex items-center justify-between text-base font-bold"><span>Total you pay</span><span className="tabular-nums text-primary">{inr(bill.total)}</span></div>
          <Row l="Wallet balance" v={inr(bill.walletBalance)} />
        </>
      )}
    </div>
  );
}
const Row = ({ l, v }: { l: string; v: string }) => (
  <div className="flex items-center justify-between text-muted-foreground"><span>{l}</span><span className="tabular-nums text-foreground">{v}</span></div>
);
