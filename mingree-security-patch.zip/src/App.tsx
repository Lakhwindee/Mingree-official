import { Switch, Route, Redirect, useLocation } from "wouter";
import { queryClient } from "@/lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { StoreProvider } from "@/lib/store";
import { AuthProvider, useAuth } from "@/lib/auth-context";
import { Toaster as SonnerToaster } from "sonner";
import { Toaster } from "@/components/ui/toaster";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { useState, useEffect } from "react";
import { SplashScreen } from "@/components/SplashScreen";

import NotFound from "@/pages/not-found";
import AboutMingree from "@/pages/AboutMingree";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import SponsorLogin from "@/pages/SponsorLogin";
import Dashboard from "@/pages/Dashboard";
import Campaigns from "@/pages/Campaigns";
import Earnings from "@/pages/Earnings";
import Profile from "@/pages/Profile";
import MyCampaigns from "@/pages/MyCampaigns";
import Offers from "@/pages/Offers";
import Groups from "@/pages/Groups";
import CategoryCampaignsPage from "@/pages/CategoryCampaigns";
import SponsorDashboard from "@/pages/sponsor/SponsorDashboard";
import SponsorCampaigns from "@/pages/sponsor/SponsorCampaigns";
import CreateCampaign from "@/pages/sponsor/CreateCampaign";
import CreateCampaignManual from "@/pages/sponsor/CreateCampaignManual";
import CreateCampaignSelect from "@/pages/sponsor/CreateCampaignSelect";
import SponsorSettings from "@/pages/sponsor/SponsorSettings";
import SponsorWallet from "@/pages/sponsor/SponsorWallet";
import AdminLogin from "@/pages/admin/AdminLogin";
import AdminDashboard from "@/pages/admin/AdminDashboard";
import Support from "@/pages/Support";
import ForgotPassword from "@/pages/ForgotPassword";
import CampaignWorkspace from "@/pages/sponsor/CampaignWorkspace";
import CreatorCampaignWorkspace from "@/pages/CreatorCampaignWorkspace";
import CreatorRequests from "@/pages/CreatorRequests";
import Terms from "@/pages/legal/Terms";
import Privacy from "@/pages/legal/Privacy";
import DataDeletion from "@/pages/legal/DataDeletion";
import Refunds from "@/pages/legal/Refunds";
import Contact from "@/pages/legal/Contact";

// Dummy icon fallbacks for removed icons
const __DummyIcon = () => null;
const Help = __DummyIcon;



import HomePage from "@/pages/HomePage";
import CreatorDirectory from "@/pages/CreatorDirectory";

// Root entry point: renders public homepage for guests & logged in users with live portal access
function RootEntry() {
  const { isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-white text-slate-900">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-rose-500 border-t-transparent" />
      </div>
    );
  }

  // Render the premium public homepage
  return <HomePage />;
}

// Protected Route wrapper for Creator
function ProtectedCreatorRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return <Redirect to="/login" />;
  }

  if (user.role === "sponsor") {
    return <Redirect to="/sponsor" />;
  }

  if (user.role === "admin") {
    return <Redirect to="/" />;
  }

  return <Component />;
}

// Protected Route wrapper for Sponsor
function ProtectedSponsorRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return <Redirect to="/login" />;
  }

  if (user.role === "creator") {
    return <Redirect to="/dashboard" />;
  }

  if (user.role === "admin") {
    return <Redirect to="/" />;
  }

  return <Component />;
}

// Guest-only Route (redirects away if already logged in)
function GuestRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return null;
  }

  if (isAuthenticated && user) {
    // Only redirect active creators and sponsors to their respective dashboards
    // Do NOT automatically hijack admins away to /admin when they want to view public pages or login
    if (user.role === "sponsor") {
      return <Redirect to="/sponsor" />;
    }
    if (user.role === "creator") {
      return <Redirect to="/dashboard" />;
    }
  }

  return <Component />;
}

// Protected Route wrapper for Admin
function AdminRoute() {
  const { user, isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex min-h-screen w-full items-center justify-center bg-slate-950 text-white">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-purple-500 border-t-transparent" />
      </div>
    );
  }

  const cleanEmail = (user?.email || "").toLowerCase().trim();
  const isAdmin = isAuthenticated && Boolean(user) && (user.role === "admin" || cleanEmail === "admin@mingree.com");

  if (isAdmin) {
    return <AdminDashboard />;
  }

  return <AdminLogin />;
}

function Router() {
  return (
    <Switch>
      {/* Public Marketplace Homepage */}
      <Route path="/" component={RootEntry} />
      <Route path="/home" component={HomePage} />
      <Route path="/creators" component={CreatorDirectory} />
      
      {/* In-app About & Help Section (Contains previous landing page info) */}
      <Route path="/about" component={AboutMingree} />

      {/* Auth Routes */}
      <Route path="/login">
        <GuestRoute component={Login} />
      </Route>
      <Route path="/signup">
        <GuestRoute component={Signup} />
      </Route>
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/sponsor/login" component={SponsorLogin} />
      
      {/* Creator Routes */}
      <Route path="/dashboard">
        <ProtectedCreatorRoute component={Dashboard} />
      </Route>
      <Route path="/campaigns">
        <ProtectedCreatorRoute component={Campaigns} />
      </Route>
      <Route path="/creator-requests">
        <ProtectedCreatorRoute component={CreatorRequests} />
      </Route>
      <Route path="/campaigns/:categoryId">
        <ProtectedCreatorRoute component={CategoryCampaignsPage} />
      </Route>
      <Route path="/my-campaigns">
        <ProtectedCreatorRoute component={MyCampaigns} />
      </Route>
      <Route path="/offers">
        <ProtectedCreatorRoute component={Offers} />
      </Route>
      <Route path="/groups">
        <ProtectedCreatorRoute component={Groups} />
      </Route>
      <Route path="/earnings">
        <ProtectedCreatorRoute component={Earnings} />
      </Route>
      <Route path="/profile">
        <ProtectedCreatorRoute component={Profile} />
      </Route>
      <Route path="/subscription">
        <Redirect to="/dashboard" />
      </Route>
      <Route path="/support" component={Support} />
      
      {/* Sponsor Routes */}
      <Route path="/sponsor">
        <ProtectedSponsorRoute component={SponsorDashboard} />
      </Route>
      <Route path="/sponsor/campaigns">
        <ProtectedSponsorRoute component={SponsorCampaigns} />
      </Route>
      <Route path="/sponsor/campaigns/:id/workspace">
        <ProtectedSponsorRoute component={CampaignWorkspace} />
      </Route>
      <Route path="/campaigns/:id/workspace">
        <ProtectedCreatorRoute component={CreatorCampaignWorkspace} />
      </Route>
      <Route path="/sponsor/create-campaign/fixed">
        <ProtectedSponsorRoute component={CreateCampaign} />
      </Route>
      <Route path="/sponsor/create-campaign/manual">
        <ProtectedSponsorRoute component={CreateCampaignManual} />
      </Route>
      <Route path="/sponsor/create-campaign">
        <ProtectedSponsorRoute component={CreateCampaignSelect} />
      </Route>
      <Route path="/sponsor/settings">
        <ProtectedSponsorRoute component={SponsorSettings} />
      </Route>
      <Route path="/sponsor/wallet">
        <ProtectedSponsorRoute component={SponsorWallet} />
      </Route>
      <Route path="/sponsor/support" component={Support} />
      
      {/* Admin Routes */}
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/dashboard">
        <Redirect to="/admin" />
      </Route>
      <Route path="/admin" component={AdminRoute} />
      
      {/* Legal Pages */}
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/data-deletion" component={DataDeletion} />
      <Route path="/refunds" component={Refunds} />
      <Route path="/contact" component={Contact} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <StoreProvider>
            <TooltipProvider>
              <SonnerToaster 
                position="top-center" 
                duration={2500}
                richColors
                toastOptions={{
                  className: "backdrop-blur-xl bg-white/70 dark:bg-black/70 border border-white/30 dark:border-white/10 shadow-2xl rounded-2xl text-foreground font-medium",
                }}
              />
              <Toaster />
              {showSplash && (
                <SplashScreen
                  durationMs={1300}
                  onFinish={() => setShowSplash(false)}
                />
              )}
              <Router />
            </TooltipProvider>
          </StoreProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
